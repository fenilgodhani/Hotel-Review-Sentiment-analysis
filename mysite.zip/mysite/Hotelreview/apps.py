from django.apps import AppConfig


class HotelreviewConfig(AppConfig):
    name = 'Hotelreview'
